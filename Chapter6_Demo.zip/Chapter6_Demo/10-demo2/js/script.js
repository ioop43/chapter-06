AOS.init({
    duration: 1000
});